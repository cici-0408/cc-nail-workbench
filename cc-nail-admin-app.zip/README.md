# Cc Nail 后台 App

这是只给店主使用的后台 App 版本。

- `index.html`：后台首页
- `manifest.webmanifest`：手机添加到主屏幕配置
- `service-worker.js`：离线缓存
- `assets/`：图标和图片

上传到 GitHub Pages / Netlify / Vercel 后，用手机 Safari 打开网址，再选择“添加到主屏幕”。
